LICENSE!

This Zip file was fully owned by @Mayopi on github platform. Do NOT use this file for commercial activity.

If you have any question please Contact Me at:

Instagram : @_mayopi
Github : @Mayopi
Twitter : @Pyoko_dayo
Email : @cyade007@gmail.com

Copyright @2022 Mayopi. All rights reserved.